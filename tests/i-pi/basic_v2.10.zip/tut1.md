# column   1     --> step : The current simulation time step.
# column   2     --> time{picosecond} : The elapsed simulation time.
# column   3     --> conserved{kelvin} : The value of the conserved energy quantity per bead.
# column   4     --> temperature{kelvin} : The current temperature, as obtained from the MD kinetic energy.
# column   5     --> potential{j/mol} : The physical system potential energy.
# column   6     --> kinetic_cv{j/mol} : The centroid-virial quantum kinetic energy of the physical system.
    0.00000000e+00     0.00000000e+00    -1.02259153e+04     2.33113437e+01    -1.14467518e+05     3.36736118e+04   
    1.00000000e+00     1.00000000e-03    -1.02245501e+04     2.32970119e+01    -1.14508860e+05     3.36736118e+04   
    2.00000000e+00     2.00000000e-03    -1.02217974e+04     2.23956606e+01    -1.14556875e+05     3.36736118e+04   
    3.00000000e+00     3.00000000e-03    -1.02178330e+04     2.20873127e+01    -1.14628905e+05     3.36736118e+04   
    4.00000000e+00     4.00000000e-03    -1.02103462e+04     2.22065467e+01    -1.14702657e+05     3.36736118e+04   
    5.00000000e+00     5.00000000e-03    -1.02022493e+04     2.25893527e+01    -1.14803005e+05     3.36736118e+04   
    6.00000000e+00     6.00000000e-03    -1.01912009e+04     2.28642331e+01    -1.14908589e+05     3.36736118e+04   
    7.00000000e+00     7.00000000e-03    -1.01787542e+04     2.24304608e+01    -1.15033166e+05     3.36736118e+04   
    8.00000000e+00     8.00000000e-03    -1.01643409e+04     2.26456271e+01    -1.15162033e+05     3.36736118e+04   
    9.00000000e+00     9.00000000e-03    -1.01498548e+04     2.30550233e+01    -1.15319446e+05     3.36736118e+04   
    1.00000000e+01     1.00000000e-02    -1.01334170e+04     2.34847641e+01    -1.15480075e+05     3.36736118e+04   
